# d5110aab-f15d-4110-b69a-e3ada7212464-bd4813f3-083a-4849-ba97-99ce37896358
https://sonar.server.examly.io/dashboard?id=iamneo-production-2_d5110aab-f15d-4110-b69a-e3ada7212464-bd4813f3-083a-4849-ba97-99ce37896358&amp;codeScope=overall
